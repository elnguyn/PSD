//
// Created by Ellie on 22/04/2024.
//
#ifndef FOODMAKER_H
#define FOODMAKER_H

#include "Food.h"
#include <vector>

class FoodMaker {
public:
    void makeFoodItems(std::vector<Food*>& foodItems);
};

#endif

//FOODMAKER_H
