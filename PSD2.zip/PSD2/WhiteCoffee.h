//
// Created by Ellie on 1/05/2024.
//
#ifndef WHITECOFFEE_H
#define WHITECOFFEE_H

#include "Drink.h"

class WhiteCoffee : public Drink {
public:
    std::string getName() override { return "White Coffee"; }
};

#endif

//UNTITLED_WHITECOFFEE_H
