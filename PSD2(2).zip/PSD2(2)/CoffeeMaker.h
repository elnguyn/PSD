//
// Created by Ellie on 22/04/2024.
//

#ifndef COFFEEMAKER_H
#define COFFEEMAKER_H

#include "Drink.h"
#include <vector>

class CoffeeMaker {
public:
    void makeCoffeeItems(std::vector<Drink*>& coffeeItems);
};

#endif
//UNTITLED_COFFEEMAKER_H
