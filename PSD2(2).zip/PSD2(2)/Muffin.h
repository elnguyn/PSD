//
// Created by Ellie on 1/05/2024.
//

#ifndef MUFFIN_H
#define MUFFIN_H

#include "Food.h"

class Muffin : public Food {
public:
    std::string getName() override { return "Muffin"; }
};

#endif
 //UNTITLED_MUFFIN_H
