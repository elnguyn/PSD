//
// Created by Ellie on 1/05/2024.
//
#ifndef BANANABREAD_H
#define BANANABREAD_H

#include "Food.h"

class BananaBread : public Food {
public:
    std::string getName() override { return "Banana Bread"; }
};

#endif
 //UNTITLED_BANANABREAD_H
