//
// Created by Ellie on 1/05/2024.
//
#ifndef FOOD_H
#define FOOD_H

#include <string>

class Food {
public:
    virtual std::string getName() = 0;
};

#endif
//UNTITLED_FOOD_H
