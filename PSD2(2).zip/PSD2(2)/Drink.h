//
// Created by Ellie on 1/05/2024.
//
#ifndef DRINK_H
#define DRINK_H

#include <string>

class Drink {
public:
    virtual std::string getName() = 0;
};

#endif
//UNTITLED_DRINK_H
